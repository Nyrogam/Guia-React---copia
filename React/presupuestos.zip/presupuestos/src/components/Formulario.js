import React, { useState } from "react";

const Formulario = () => {
  return (
    <form>
      <h2></h2>
      <div className="campo">
        <label> Nombre del Gasto</label>
      </div>
    </form>
  );
};

export default Formulario;
